package tr.com.memurtakip;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final String[] cities = {"81 ilin tamamı","Adana","Adıyaman","Afyonkarahisar","Ağrı","Aksaray","Amasya","Ankara","Antalya","Artvin","Aydın","Balıkesir","Bilecik","Bingöl","Bitlis","Bolu","Burdur","Bursa","Çanakkale","Çankırı","Çorum","Denizli","Diyarbakır","Edirne","Elazığ","Erzincan","Erzurum","Eskişehir","Gaziantep","Giresun","Gümüşhane","Hakkâri","Hatay","Iğdır","Isparta","İstanbul","İzmir","Kahramanmaraş","Karabük","Karaman","Kars","Kastamonu","Kayseri","Kırıkkale","Kırklareli","Kırşehir","Kilis","Kocaeli","Konya","Kütahya","Malatya","Manisa","Mardin","Mersin","Muğla","Muş","Nevşehir","Niğde","Ordu","Osmaniye","Rize","Sakarya","Samsun","Siirt","Sinop","Sivas","Şanlıurfa","Şırnak","Tekirdağ","Tokat","Trabzon","Tunceli","Uşak","Van","Yalova","Yozgat","Zonguldak","Düzce"};
    LinearLayout content, root;
    EditText search;
    Spinner citySpinner, eduSpinner, typeSpinner;
    TextView status;
    ArrayList<String> saved = new ArrayList<>();
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(17,19,24));
        getWindow().setNavigationBarColor(Color.rgb(17,19,24));
        saved = new ArrayList<>(getPreferences(0).getStringSet("saved", new HashSet<>()));
        build();
    }
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density); }
    TextView text(String s, int size, int color, boolean bold) {
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,1); t.setPadding(dp(2),dp(5),dp(2),dp(5)); return t;
    }
    void build() {
        root=new LinearLayout(this); root.setOrientation(1); root.setBackgroundColor(Color.rgb(17,19,24));
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(1); content.setPadding(dp(16),dp(12),dp(16),dp(24));
        scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView title=text("MEMUR TAKİP",25,Color.WHITE,true); content.addView(title);
        content.addView(text("81 il • KPSS'li ve KPSS'siz kamu alımları",13,0xFFB8C0CC,false));
        LinearLayout nav=new LinearLayout(this);
        Button all=button("İlanlar"), fav=button("Favoriler"), sources=button("Resmî kaynaklar");
        nav.addView(all,new LinearLayout.LayoutParams(0,dp(44),1)); nav.addView(fav,new LinearLayout.LayoutParams(0,dp(44),1)); nav.addView(sources,new LinearLayout.LayoutParams(0,dp(44),1));
        content.addView(nav);
        all.setOnClickListener(v->showListings(false)); fav.setOnClickListener(v->showListings(true)); sources.setOnClickListener(v->showSources());
        content.addView(text("İlan filtreleri",17,Color.WHITE,true));
        search=new EditText(this); search.setSingleLine(true); search.setHint("Meslek, kurum veya bölüm ara"); content.addView(search);
        citySpinner=spinner(cities); content.addView(citySpinner);
        eduSpinner=spinner(new String[]{"Tüm eğitim seviyeleri","Lise","Ön lisans","Lisans"}); content.addView(eduSpinner);
        typeSpinner=spinner(new String[]{"Tüm alımlar","KPSS'li","KPSS'siz"}); content.addView(typeSpinner);
        Button apply=button("Filtreleri uygula"); content.addView(apply); apply.setOnClickListener(v->showListings(false));
        status=text("Henüz doğrulanmış canlı ilan bağlantısı kurulmadı. Bu sürüm resmî kaynaklara erişim ve takip listesi başlangıç ekranıdır.",12,0xFFFFD180,false); content.addView(status);
        showListings(false);
        setContentView(root);
    }
    Spinner spinner(String[] values){ Spinner s=new Spinner(this); ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values); s.setAdapter(a); return s; }
    Button button(String label){ Button b=new Button(this); b.setText(label); b.setTextColor(Color.WHITE); b.setAllCaps(false); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFB3261E)); return b; }
    void showListings(boolean onlySaved) {
        clearAfterFilters();
        content.addView(text(onlySaved?"Favorilerim":"İlan panosu",19,Color.WHITE,true));
        if(onlySaved && saved.isEmpty()){ content.addView(text("Henüz favori ilan eklemedin.",14,0xFFCFD3DA,false)); return; }
        content.addView(text("Canlı ilanlar bu başlangıç sürümünde henüz otomatik alınmıyor. Doğrulanmış ilan akışı bağlandığında burada kurum, kadro, şehir, şartlar ve son başvuru tarihi gösterilecek.",14,0xFFCFD3DA,false));
        content.addView(text("Şimdilik resmî duyuru kaynaklarına aşağıdan ulaşabilir, ilan bağlantılarını kontrol edebilirsin.",13,0xFFB8C0CC,false));
        Button src=button("Resmî kaynakları aç"); content.addView(src); src.setOnClickListener(v->showSources());
    }
    void clearAfterFilters(){ int start=content.indexOfChild(status)+1; while(content.getChildCount()>start)content.removeViewAt(start); }
    void showSources() {
        clearAfterFilters(); content.addView(text("Resmî ilan kaynakları",19,Color.WHITE,true));
        addLink("Kariyer Kapısı","https://kariyerkapisi.gov.tr/");
        addLink("ÖSYM","https://www.osym.gov.tr/");
        addLink("İŞKUR","https://www.iskur.gov.tr/");
        addLink("Resmî Gazete","https://www.resmigazete.gov.tr/");
        addLink("İlan.gov.tr","https://www.ilan.gov.tr/");
        addLink("Cumhurbaşkanlığı / kamu duyuruları","https://www.turkiye.gov.tr/");
        content.addView(text("Not: Kaynak bağlantıları resmî sitelere yönlendirir. Otomatik ilan toplama, tekrar kontrolü ve bildirimler için kaynakların veri erişim yöntemlerinin ayrıca entegre edilmesi gerekir.",12,0xFFFFD180,false));
    }
    void addLink(String label,String url){ Button b=button(label+"  ↗"); content.addView(b); b.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}catch(Exception e){}}); }
}
