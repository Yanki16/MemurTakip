# Memur Takip - Android başlangıç projesi

## Telefon üzerinden APK derleme (GitHub Actions)

1. ZIP dosyasını telefona indirin ve çıkarın.
2. GitHub uygulamasında veya tarayıcıda yeni, **Public** ya da **Private** repository oluşturun.
3. Repository içindeki **Add file > Upload files** bölümünden bu klasörün içindeki tüm dosya ve klasörleri yükleyin. `.github/workflows/android-apk.yml` dosyasının da yüklendiğini kontrol edin.
4. Dosyaları `main` dalına commit edin.
5. Repository'de **Actions** sekmesine girin. `Android APK` iş akışı otomatik başlamalıdır. Başlamazsa iş akışını açıp **Run workflow** seçin.
6. İşlem yeşil tik ile bittiğinde çalıştırma kaydını açın.
7. Sayfanın altındaki **Artifacts** bölümünden `Memur-Takip-debug-APK` dosyasını indirin.
8. ZIP içinden `app-debug.apk` dosyasını çıkarıp Android telefona kurun. Android, tarayıcıya/dosya yöneticisine bu kurulum için izin isteyebilir.

## Proje içeriği
- Android Java uygulama başlangıcı
- Koyu/kırmızı tema
- 81 il seçimi
- Eğitim ve KPSS türü filtre alanları
- Resmî kamu duyuru kaynaklarına bağlantılar
- GitHub Actions ile bulutta debug APK derleme iş akışı

## Dürüst durum notu
Bu APK bir **başlangıç prototipidir**. Canlı ilanları otomatik toplama, ilan doğrulama, yinelenen ilanları ayıklama, KPSS puanı/bölüm uygunluk motoru, yerel bildirimler ve başvuru verilerinin kalıcı kaydı henüz tamamlanmamıştır. Resmî kaynakların veri erişim yöntemleri entegre edilmeden canlı ilan varmış gibi gösterilmez.

Bu ilk derleme debug APK üretir; Google Play'e dağıtım için imzalı release paketi ve ek testler gerekir.
